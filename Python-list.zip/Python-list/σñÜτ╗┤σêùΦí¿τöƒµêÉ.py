s1 = [0, 1, 2, 3, 4, 5, 6]
s2 = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT']
s5 = []
for i in range(len(s1)):
    s5.append([s1[i], s2[i]])
print(s5)
